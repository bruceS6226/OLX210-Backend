module.exports = {
    database: {
        host: 'localhost',
        user: 'root',
        password: 'conmigo6226DCM',
        port: 3306,
        database: 'olx8'
    }
}