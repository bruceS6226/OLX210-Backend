import { Router } from 'express';
import { loginUsuario, crearUsuario, obtenerUsuarios, actualizarUsuario, eliminarUsuario} from '../controllers/usuarioController';
import validateToken from './validate-token';

const router = Router();

router.post('/', crearUsuario);
router.post('/login', loginUsuario);
router.get('/',validateToken, obtenerUsuarios);
router.put('/:id', validateToken, actualizarUsuario);
router.delete('/:id', validateToken, eliminarUsuario);

export default router;