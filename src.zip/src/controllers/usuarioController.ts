import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { Usuario } from '../models/usuario';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import path from 'path';
import { subirImagen } from '../middlewares/cargarImagenMiddleware';

export const crearUsuario = async (req: Request, res: Response) => {
    try {
        //manejar la subida de la imagen utilizando Multer
        subirImagen(req, res, async (err: any) => {
            if (err instanceof multer.MulterError) {
                return res.status(400).json({
                    msg: 'Error al subir la imagen',
                    error: err,
                });
            } else if (err) {
                return res.status(500).json({
                    msg: 'Error interno del servidor',
                    error: err,
                });
            }
            const { nombre, apellido, correo, telefono, genero, cedula_RUC, contrasenia, fecha_nacimiento, longitud, latitud } = req.body;
            //validacion si el correo existe en la base de datos
            const existeCorreo = await Usuario.findOne({ where: { correo: correo } });
            if (existeCorreo) {
                return res.status(400).json({
                    msg: `Ya existe un usuario con el correo: ${correo}`
                })
            }
            //validacion si el telefono existe en la base de datos
            const existeTelefono = await Usuario.findOne({ where: { telefono: telefono } });
            if (existeTelefono) {
                return res.status(400).json({
                    msg: `Ya existe un usuario con el teléfono: ${telefono}`
                })
            }
            //obtener la ruta de la imagen si se subio o establecerla como cadena vacia si no hay imagen// Obtener la ruta de la imagen si se subió o establecerla como la imagen por defecto si no hay imagen
            let foto = '';
            if (req.file) {
                foto = path.join('uploads', req.file.filename);
            } else {
                // Establecer la imagen por defecto
                foto = path.join('uploads', '2e5a8af2-d1da-4507-aca5-8d86688932c9.png');
            }

            //encriptar contraseña
            const hashedContrasenia = await bcrypt.hash(contrasenia, 10);

            await Usuario.create({
                foto: foto,
                nombre: nombre,
                apellido: apellido,
                correo: correo,
                telefono: telefono,
                genero: genero,
                cedula_RUC: cedula_RUC,
                contrasenia: hashedContrasenia,
                fecha_nacimiento: fecha_nacimiento,
                longitud: longitud,
                latitud: latitud
            });

            res.json({
                msg: `Bienvenido ${nombre} ${apellido}!`
            });
        });
    } catch (error) {
        res.status(400).json({
            msg: 'Ha ocurrido un error',
            error: error
        });
    }
};


export const loginUsuario = async (req: Request, res: Response) => {
    const { correo, contrasenia } = req.body;
    //validacion si el usuario existe en la base de datos
    const existeUsuario = await Usuario.findOne({ where: { correo: correo } });
    if (!existeUsuario) {
        return res.status(400).json({
            msg: `No existe un usuario con el correo: ${correo}`
        })
    }
    //validacion contraseña
    const contraseniaValida = await bcrypt.compare(contrasenia, existeUsuario.contrasenia);
    if (!contraseniaValida) {
        return res.status(400).json({
            msg: 'Contraseña incorrecta'
        })
    }
    //generacion token
    const token = jwt.sign({
        correo: correo
    }, process.env.SECRET_KEY || 'claveSecretaOLX8'
        //, {expiresIn: '1000000'}
    );
    res.json(token);
}

export const obtenerUsuarios = async (req: Request, res: Response) => {
    const listaUsuarios = await Usuario.findAll();
    res.json(listaUsuarios)
}

export const actualizarUsuario = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { nombre, apellido, correo, telefono, genero, cedula_RUC, contrasenia, fecha_nacimiento, longitud, latitud } = req.body;

        //validar si el usuario existe en la base de datos
        const usuarioExistente = await Usuario.findByPk(id);

        if (!usuarioExistente) {
            return res.status(404).json({
                msg: `No se encontró un usuario con el id: ${id}`
            });
        }

        //actualizar solo los campos proporcionados
        if (nombre) usuarioExistente.nombre = nombre;
        if (apellido) usuarioExistente.apellido = apellido;
        if (correo) usuarioExistente.correo = correo;
        if (telefono) usuarioExistente.telefono = telefono;
        if (genero) usuarioExistente.genero = genero;
        if (cedula_RUC) usuarioExistente.cedula_RUC = cedula_RUC;
        if (fecha_nacimiento) usuarioExistente.fecha_nacimiento = fecha_nacimiento;
        if (longitud) usuarioExistente.longitud = longitud;
        if (latitud) usuarioExistente.latitud = latitud;

        //encriptar la nueva contraseña si se proporciona
        if (contrasenia) {
            const hashedContrasenia = await bcrypt.hash(contrasenia, 10);
            usuarioExistente.contrasenia = hashedContrasenia;
        }

        //guardar los cambios en la base de datos
        await usuarioExistente.save();

        res.json({
            msg: `Usuario con id ${id} actualizado exitosamente`
        });
    } catch (error) {
        res.status(400).json({
            msg: 'Ha ocurrido un error al actualizar el usuario',
            error: error
        });
    }
};

export const eliminarUsuario = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        //validar si el usuario existe en la base de datos
        const usuarioExistente = await Usuario.findByPk(id);

        if (!usuarioExistente) {
            return res.status(404).json({
                msg: `No se encontró un usuario con el id: ${id}`
            });
        }
        //eliminar el usuario de la base de datos
        await usuarioExistente.destroy();

        res.json({
            msg: `Usuario con id ${id} eliminado exitosamente`
        });
    } catch (error) {
        res.status(400).json({
            msg: 'Ha ocurrido un error al eliminar el usuario',
            error: error
        });
    }
};