import crypto from "crypto";
import { NextFunction, Request, Response } from "express";
import multer, { FileFilterCallback } from "multer";
import path from "path";

const uuid = crypto.randomUUID();

//definir el almacenamiento de archivos
const storage = multer.diskStorage({
  destination: path.join(__dirname, "../../src/subirImagens"),
  filename: function (
    req: Request,
    file: Express.Multer.File,
    cb: (error: Error | null, destination: string) => void
  ) {
    cb(null, uuid + file.originalname.substring(file.originalname.lastIndexOf(".")));
  },
});

//filtrar por tipos MIME
const fileFilter = (
  req: Request,
  file: Express.Multer.File,
  cb: FileFilterCallback
) => {
  const fileTypes = ["image/png", "image/jpg", "image/jpeg", "image/gif"];

  if (fileTypes.some((fileType) => fileType === file.mimetype)) {
    return cb(null, true);
  }

  return cb(null, false);
};

const maxSize = 5 * 1024 * 1024;
//esta funcion permite subir una imagen y en caso de estar vacia solo subiria null
export const subirImagen = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  return multer({
    storage,
    limits: { fileSize: maxSize },
    fileFilter,
  }).single("foto")(req, res, (err) => {
    //exito
    next();
  });
};

export const actualizarImagen = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  return multer({
    storage,
    limits: { fileSize: maxSize },
    fileFilter,
  }).single("foto")(req, res, (err) => {
    // Error de tamaño de archivo
    if (err instanceof multer.MulterError) {
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json("Tamaño máximo de archivo permitido: 5MB");
      } else {
        return res.status(400).json("Error al subir el archivo");
      }
    }
    //tipo de archivo no valido, el mensaje vendra del callback fileFilter
    if (err) {
      return res.status(400).json(err.message);
    }
    //archivo no seleccionado o formato incorrecto
    if (!req.file) {
      return res.status(400).json({
        msg: "No se ha subido ningún archivo. Recuerda que solo puedes subir formatos .jpeg, .jpg, .png y .gif.",
      });
    }
    //exito
    next();
  });
};