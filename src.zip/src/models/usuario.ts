import { DataTypes, Model } from 'sequelize';
import sequelize from '../db/connection';

class Usuario extends Model {
  public id_usuario!: number;
  public foto!: string | null;
  public nombre!: string;
  public apellido!: string;
  public correo!: string;
  public telefono!: string;
  public genero!: string | null;
  public cedula_RUC!: string | null;
  public contrasenia!: string;
  public fecha_nacimiento!: Date;
  public longitud!: string;
  public latitud!: string;
}

Usuario.init(
  {
    id_usuario: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      field: 'id_usuario',
    },
    foto: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    nombre: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    apellido: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    correo: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    telefono: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    genero: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    cedula_RUC: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    contrasenia: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'contrasenia',
    },
    fecha_nacimiento: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    longitud: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    latitud: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: 'Usuario',
    tableName: 'usuarios',
    timestamps: false,
  }
);

export { Usuario };
