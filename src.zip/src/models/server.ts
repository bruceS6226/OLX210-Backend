import express, { Application } from 'express';
import cors from 'cors';
import routesUser from '../routes/usuarioRoutes';
import { Usuario } from './usuario';

class Server {
    private app: Application;
    private port: string;

    constructor() {
        this.app = express();
        this.port = process.env.PORT || '3000';
        this.listen();
        this.midlewares();
        this.routes();
        this.dbConnect();

    }

    //iniciar aplicacion
    listen() {
        this.app.listen(this.port, () => {
            console.log('Servidor funcionando en el puerto ' + this.port);
        })
    }

    //importar rutas
    routes() {
        this.app.use('/api/users/', routesUser);
    }

    //middlewares(funciones que se ejecutan antes de las peticiones de los usuarios)
    midlewares() {
        // Parseo body
        this.app.use(express.json());

        // Cors
        this.app.use(cors());
    }

    async dbConnect() {
        try {
            await Usuario.sync();
        } catch (error) {
            console.error('Unable to connect to the database:', error);
        }
    }
}

export default Server;